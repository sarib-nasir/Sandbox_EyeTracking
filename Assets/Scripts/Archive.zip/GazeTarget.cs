using UnityEngine;

public class GazeTarget : MonoBehaviour
{
    public string objectLabel = "";
    void Start()
    {
        if (string.IsNullOrEmpty(objectLabel))
        {
            objectLabel = gameObject.name;
        }
        Debug.Log("Gaze target clicked: " + objectLabel);
    }
}
